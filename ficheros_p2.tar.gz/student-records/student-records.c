#include "defs.h"


char* loadstr(FILE * file)
{
}

student_t*  parse_records(char* records[], int nr_records)
{
}

int dump_entries(student_t* entries, int nr_entries, FILE* students)
{
}

student_t* read_student_file(FILE* students, int* nr_entries)
{
}

int main(int argc, char *argv[])
{
}
