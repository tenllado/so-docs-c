#include <stdio.h>
#include <stdlib.h>

/*programa que crea dos hijos: uno no cambia de ejecutable y otro si */


int main(int argc, char **argv)
{

	return 0;
}
